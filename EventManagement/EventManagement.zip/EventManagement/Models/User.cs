﻿namespace EventManagement.Models
{
    public class User
    {
        public int UserId { get; set; }
        public string username { get; set; }

        public string password { get; set; }
    }
}